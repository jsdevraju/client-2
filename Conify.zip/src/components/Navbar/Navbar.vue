<template>
  <header>
    <div class="container p-4">
      <a href="#" class="font-weight-bold d-flex align-items-center">
        <img src="../../assets/logo.png" alt="Coinfy" width="150" />
      </a>
    </div>
  </header>
</template>

<script>
export default {};
</script>




<style scoped>

</style>
