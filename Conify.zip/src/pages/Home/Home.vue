<template>
    <Hero />
    <About />
</template>

<script>
import Hero from '../../sections/Hero/Hero.vue';
import About from '../../sections/About/About.vue';
    export default {
    components: { Hero, About }
}
</script>

<style>

</style>